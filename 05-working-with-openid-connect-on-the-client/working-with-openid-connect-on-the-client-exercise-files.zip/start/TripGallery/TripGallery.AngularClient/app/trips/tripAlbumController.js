﻿(function () {
    "use strict";
    angular
        .module("tripGallery")
        .controller("tripAlbumController",
                     [TripAlbumController]);

    function TripAlbumController() {
        var vm = this;      
    }
}());
